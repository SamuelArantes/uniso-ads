/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controle;

import Modelo.Veiculo;
import java.util.ArrayList;

/**
 *
 * @author pauca
 */
public class ControleVeiculo {
    
    ArrayList<Veiculo> veiculos = new ArrayList<>();
    
    public boolean Salvar (Veiculo v) {
        if (v != null){
            veiculos.add(v);
            return true;
        } else {
            return false;
        }
    }
    
    public ArrayList<Veiculo> retornarVeiculo (){
        return veiculos;
    }
}
