/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controle;

import Modelo.Cliente;
import java.util.ArrayList;

/**
 *
 * @author pauca
 */
public class ControleCliente {
    
    ArrayList<Cliente> clientes = new ArrayList<>();
    
    public boolean Salvar (Cliente c) {
        if (c != null){
            clientes.add(c);
            return true;
        } else {
            return false;
        }
    }
    
    public ArrayList<Cliente> retornarCliente (){
        return clientes;
    }
}
