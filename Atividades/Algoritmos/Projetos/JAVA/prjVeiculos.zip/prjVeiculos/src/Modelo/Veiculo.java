/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author pauca
 */
public class Veiculo {
    
    private String placa;
    private String modelo;
    private String ano;
    private String Fabricante;
    private String Cor;

    public Veiculo() {
    }

    public Veiculo(String placa, String modelo, String ano, String Fabricante, String Cor) {
        this.placa = placa;
        this.modelo = modelo;
        this.ano = ano;
        this.Fabricante = Fabricante;
        this.Cor = Cor;
    }

    public String getCor() {
        return Cor;
    }

    public void setCor(String Cor) {
        this.Cor = Cor;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getAno() {
        return ano;
    }

    public void setAno(String ano) {
        this.ano = ano;
    }

    public String getFabricante() {
        return Fabricante;
    }

    public void setFabricante(String Fabricante) {
        this.Fabricante = Fabricante;
    }
    
    
    
}
